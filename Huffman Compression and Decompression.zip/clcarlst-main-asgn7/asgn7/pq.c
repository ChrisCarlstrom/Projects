#include "pq.h"
#include "heap.h"
#include "node.h"
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

typedef struct PriorityQueue { // create the struct for priority queue with the
                               // fields of a Node array, a current size
                               // variable and a capacity variable
  Node **arr;
  uint32_t size;
  uint32_t capacity;
} PriorityQueue;

PriorityQueue *pq_create(uint32_t capacity) {
  PriorityQueue *q = (PriorityQueue *)calloc(
      capacity,
      sizeof(PriorityQueue)); // creates a pq and checks if it was created
                              // properly, if not it returns as NULL
  if (q != NULL) {
    q->capacity =
        capacity; // sets the pq's capacity as the inputted capacity value
    q->size = 0;  // sets the pq's current size to 0
    q->arr = (Node **)malloc(
        q->capacity *
        sizeof(Node *)); // allocates the capacity amount of space for the node
                         // array, if it was not created correctly then free the
                         // pq and set it to NULL
    if (q->arr == NULL) {
      free(q);
      q = NULL;
    }
  }
  return q;
}

void pq_delete(PriorityQueue **q) {
  if ((*q) != NULL) { // checks if the pq is not NULL, if yes then checks if the
                      // pq node array isnt NULL
    if ((*q)->arr != NULL) {
      free((*q)->arr); // frees the node array and sets it to NULL
      (*q)->arr = NULL;
    }
    free((*q)); // fress the pq and sets it to NULL
    (*q) = NULL;
  }
}

bool pq_empty(PriorityQueue *q) {
  if (q != NULL) { // checks if the pq is not NULL, if yes it returns the size
                   // field of teh pq and true, else returns false
    if (q->size == 0) {
      return true;
    }
  }
  return false;
}

bool pq_full(PriorityQueue *q) {
  if (q != NULL) { // checks if the pq is not NULL, if yes it checks if the size
                   // and capacity are equal, if yes then it returns true,
                   // otherwise it will return false
    if (q->size == q->capacity) {
      return true;
    }
  }
  return false;
}

uint32_t pq_size(PriorityQueue *q) {
  return q->size; // returns the size field of pq
}

bool enqueue(PriorityQueue *q, Node *n) {
  if (q != NULL) {            // checks if pq isnt NULL, if no it returns false
    if (pq_full(q) == true) { // checks if pq is full, if yes it returns false
      return false;
    }
    q->arr[q->size] =
        n; // set the inputted node at the next open spot in the pq array
    up_heap(q->arr, q->size); // call up heap on the pq array and increment the
                              // size returning true
    q->size += 1;
    return true;
  }
  return false;
}

bool dequeue(PriorityQueue *q, Node **n) {
  if (q != NULL) { // checks if pq isnt NULL, if no then it returns false
    if (pq_empty(q) == true) { // if the pq is empty then return false
      return false;
    }
    uint32_t temp = q->size; // store the size - 1 index of the pq array in temp
    temp -= 1;
    node_swap(q->arr[0],
              q->arr[temp]); // swap the 0th index of the array and temp
    (*n) = q->arr[temp]; // set the passed in Node n to the pq array value of
                         // temp and decrement the size
    q->size -= 1;
    down_heap(q->arr, q->size); // call down heap on the pq array and return
                                // true
    return true;
  }
  return false;
}

void pq_print(PriorityQueue *q) {
  for (uint64_t i = 0; i < q->size;
       i += 1) { // loops through the size of the pq array and prints all of the
                 // nodes
    node_print(q->arr[i]);
  }
}
