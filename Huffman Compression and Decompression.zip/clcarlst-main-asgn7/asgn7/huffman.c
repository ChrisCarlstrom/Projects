#include "huffman.h"
#include "code.h"
#include "defines.h"
#include "heap.h"
#include "io.h"
#include "node.h"
#include "pq.h"
#include "stack.h"
#include <fcntl.h>
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

extern Code pass; // initialize code object as extern to be used in build_codes

Node *build_tree(
    uint64_t
        hist[static ALPHABET]) { // this part is essentially the pre-work before
                                 // we can build the tree, we muct fill the pq
                                 // with all of the elements from the histogram
  PriorityQueue *pq =
      pq_create(ALPHABET); // creates a pq object with capacity ALPHABET
  for (uint32_t i = 0; i < ALPHABET;
       i +=
       1) { // loops through the inputted histogram and check if the value is
            // not 0, if yes then create a node with the ascii value of the
            // index as the symbol and the value of the index in the histogram
            // as the frequency, then enqueue the node into the pq
    if (hist[i] != 0) {
      Node *n = node_create(i, hist[i]);
      enqueue(pq, n);
    }
  }
  while (
      pq_size(pq) !=
      1) { // now that we have the priorityqueue we loop through it while the
           // length of the pq isn't 1, initialize a node for the left and right
           // children, dequeue 2 nodes from the pq and store the nodes in the
           // just created left and right nodes, then create a parent node by
           // calling node_join to combine the nodes and enquque then new node
           // back into the pq. This will dwindle the number of nodes in the pq
           // by combining them and saving the left and right children until
           // there is only one node left in the pq, which will be the root.
    Node *left;
    Node *right;
    dequeue(pq, &left);
    dequeue(pq, &right);
    Node *parent = node_join(left, right);
    enqueue(pq, parent);
  }
  Node *root; // create a root node pointer and dequeue the last node in the pq
              // into the root pointer, then return the root
  dequeue(pq, &root);
  pq_delete(&pq);
  return root;
}

void build_codes(Node *root, Code table[static ALPHABET]) {
  if (root !=
      NULL) { // check if the root isn't NULL, if it isn't, check if the node's
              // left and right children are NULL, if that is true, then set the
              // current node's ascii value's index of the code table to the
              // code that aligns with that node
    if (root->left == NULL && root->right == NULL) {
      table[root->symbol] = pass;
    } else { // if either one or both of the node's children are not NULL then
             // push a 0 bit into pass's bit array and call build codes again,
             // then pop a bit off of pass's bit array and save that bit in the
             // bit1 variable
      code_push_bit(&pass, 0);
      build_codes(root->left, table);
      uint8_t bit1;
      code_pop_bit(&pass, &bit1);

      code_push_bit(
          &pass, 1); // do the same as just described except instead we will
                     // push a 1 onto the bits array in pass and recurse through
                     // the right side of the tree rather than the left
      build_codes(root->right, table);
      uint8_t bit2;
      code_pop_bit(&pass, &bit2);
    }
  }
}

void dump_tree(int outfile, Node *root) {
  if (root) { // if the root doesnt equal NULL then call dump_tree on both the
              // left and right children of the root
    dump_tree(outfile, root->left);
    dump_tree(outfile, root->right);
    if (root->left == NULL &&
        root->right ==
            NULL) { // if both children of the current node are NULL then we
                    // will create a buffer to store the current node as a leaf
                    // and the symbol of the current node, we will write these
                    // to the outfile to produce a code of how the tree is laid
                    // out to be rebuilt in rebuild_tree
      uint8_t buf1[2];
      buf1[0] = 'L';
      buf1[1] = root->symbol;
      write_bytes(outfile, buf1, 2);
    } else { // if either the left or right child of the current node wasn't
             // NULL then we want to ceate a buffer that will store the vurrent
             // node as an Interior node, meaning that it is not a leaf and has
             // children, also it doesn't have a symbol since it isnt a leaf so
             // all we need to add to the outfile is an I
      uint8_t buf2[1];
      buf2[0] = 'I';
      write_bytes(outfile, buf2, 1);
    }
  }
}

Node *rebuild_tree(uint16_t nbytes, uint8_t tree_dump[static nbytes]) {
  Stack *s = stack_create(nbytes); // create a stack object that will be used to
                                   // store all of the nodes form the infile
  for (uint16_t i = 0; i < nbytes;
       i +=
       1) { // loop through the tree dump that was created in dump_tree, if the
            // current index is an L, meaning that it is a leaf node, then
            // create a node that has the symbol that follows the current index
            // L and push the node onto the stack, also increment the index
            // again to skip over the symbol that followed the L
    if (tree_dump[i] == 'L') {
      Node *leaf = node_create(tree_dump[i + 1], 0);
      stack_push(s, leaf);
      i += 1;
    } else if (tree_dump[i] ==
               'I') { // if the current index is an I then that means we found
                      // an interior node and we need to create node pointers
                      // for the left and right children that are popped off the
                      // stack. Pop 2 nodes off the stack storing them in these
                      // pointers and join the nodes together with node_join,
                      // creating a parent node. Push the newly created node
                      // from joining two others back onto the stack, this
                      // slowly reduces the amount of nodes in the stack until
                      // one is left, which is the root
      Node *right;
      Node *left;
      stack_pop(s, &right);
      stack_pop(s, &left);
      Node *interior = node_join(left, right);
      stack_push(s, interior);
    }
  }
  Node *root; // pop the root from the stack and return the root
  stack_pop(s, &root);
  stack_delete(&s);
  return root;
}

void delete_tree(Node **root) {
  if (*root) { // if the root is not NULL, recursively call delete_tree on the
               // current nodes left and right children, this goes down the tree
               // in a post order traversal and deletes the tree from the leaves
               // first then all the way back up until the root is the only node
               // left in the tree. Once that happens we delete the root node
               // and return
    delete_tree(&(*root)->left);
    delete_tree(&(*root)->right);
    node_delete(root);
  }
}
