#include "node.h"
#include "heap.h"
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

void node_swap(Node *one, Node *two) { // create node swap function to be used
                                       // when calling up_heap and down_heap
  Node temp = *one;
  *one = *two;
  *two = temp;
}

uint32_t l_child(uint32_t n) {
  return 2 * n + 1; // left child value
}

uint32_t r_child(uint32_t n) {
  return 2 * n + 2; // right child value
}

uint32_t parent(uint32_t n) {
  return (n - 1) / 2; // parent value
}

void up_heap(Node **arr, uint32_t n) {
  while ((n > 0) &&
         (node_cmp(arr[n], arr[parent(n)]) ==
          false)) { // checks if parent is greater than the given array value
    node_swap(arr[n], arr[parent(n)]); // swaps the parent and given array value
    n = parent(n);
  }
}

void down_heap(Node **arr, uint32_t heap_size) {
  uint32_t n = 0;
  uint32_t smaller;
  while (l_child(n) <
         heap_size) { // checks if the left child is less than the size of heap
    if (r_child(n) ==
        heap_size) { // checks if the right child is equal to the size of heap
      smaller = l_child(n);
    } else {
      if (node_cmp(arr[l_child(n)], arr[r_child(n)]) ==
          false) { // checks if right child is greater than left child
        smaller = l_child(n); // if yes, sets smaller equal to the left child
      } else {
        smaller = r_child(n); // if not, sets smaller to the right child
      }
    }
    if (node_cmp(arr[n], arr[smaller]) ==
        false) { // checks if the array value of smaller is greater than the
                 // current array value
      break;
    }
    node_swap(arr[smaller],
              arr[n]); // if the previosu line returned true, swaps array value
                       // of smaller and the current array value
    n = smaller;
  }
}
