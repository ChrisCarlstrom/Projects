#include "node.h"
#include <ctype.h>
#include <inttypes.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

Node *node_create(uint8_t symbol, uint64_t frequency) {
  Node *n = (Node *)malloc(sizeof(Node)); // allocates space for node
  if (n == NULL) { // checks if the node wasn't created correctly, if it wasnt
                   // then free the node and and return the NULL node
    free(n);
    n = NULL;
    return n;
  }
  n->symbol = symbol;       // set the inputted symbol to the node's symbol
  n->frequency = frequency; // set the inputted frequency to the node's
                            // frequency
  n->left = NULL; // set the nodes left and rigt pointers to NULL and return the
                  // pointer
  n->right = NULL;
  return n;
}

void node_delete(Node **n) {
  if (*n) {            // check if the node is not NULL
    (*n)->left = NULL; // if the node isn't NULL then set the left and right
                       // pointers to NULL, free the node and set it to NULL
    (*n)->right = NULL;
    free(*n);
    *n = NULL;
  }
}

Node *node_join(Node *left, Node *right) {
  uint64_t new_freq =
      (left->frequency +
       right->frequency); // adds the left and right frequencies together
  uint8_t new_sym =
      (uint8_t)'$'; // sets a uint8_t to $ to be the symbol of the joined node
  Node *parent =
      node_create(new_sym, new_freq); // creates a new node that has the added
                                      // frequencies and the new symbol
  if (parent !=
      NULL) { // if the parent isn't NULL set the parent's left node to the left
              // node and do the same for the parent's right node pointer
    parent->left = left;
    parent->right = right;
  } else { // free the parent if it is NULL and return the parent node
    free(parent);
    parent = NULL;
  }
  return parent;
}

void node_print(Node *n) {
  if (n == NULL) { // if the node is NULL then just return since theres nothing
                   // to print
    return;
  }
  if (iscntrl(n->symbol) !=
      0) { // if the node has a symbol then print the symbol and frequency, else
           // just print the frequency
    printf("0x%02X\n%lu\n", n->symbol, n->frequency);
  } else {
    printf("%c\n%lu\n", n->symbol, n->frequency);
  }
}

bool node_cmp(Node *one, Node *two) {
  if (one->frequency > two->frequency) { // if node one is greater then node two
                                         // then return true, else return false
    return true;
  } else {
    return false;
  }
}

void node_print_sym(Node *n) {
  if (n == NULL) { // if the node is NULL then just return since theres nothing
                   // to print
    return;
  }
  if (iscntrl(n->symbol) !=
      0) { // checks if the symbol of the node is a printable symbol, chooses
           // the correct print statement with the symbol that the node
           // possesses
    printf("0x%02X\n", n->symbol);
  } else {
    printf("%c\n", n->symbol);
  }
}
