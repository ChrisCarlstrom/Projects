#include "code.h"
#include "defines.h"
#include "heap.h"
#include "node.h"
#include "pq.h"
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

Code code_init(void) { // initialize the code struct with fields top and
                       // bits(bits being a bits array)
  Code c;
  c.top = 0;
  for (uint64_t i = 0; i < MAX_CODE_SIZE; i += 1) {
    c.bits[i] = 0;
  }
  return c;
}

uint32_t code_size(Code *c) {
  return c->top; // returns the top field of the code object
}

bool code_empty(Code *c) {
  if (c->top == 0) { // if the top field of the code object is 0 then returns
                     // true, else returns false
    return true;
  }
  return false;
}

bool code_full(Code *c) {
  if (c->top ==
      MAX_CODE_SIZE *
          8) { // uf the top field of the code object is equal to max code size
               // times 8 then return true, else returns false
    return true;
  }
  return false;
}

bool code_set_bit(Code *c, uint32_t i) {
  if (i > c->top) { // returns false if the inputted index is greater than the
                    // value of top
    return false;
  }
  uint32_t temp_i = i; // divides the inputted index i by 8 to find the specific
                       // byte that the index is in and modulo the specified
                       // index by 8 to find the specific bit the index is in
  uint8_t byte = i / 8;
  uint8_t bit = temp_i % 8;
  c->bits[byte] |= (1UL << (bit)); // bitwise or shifts the desired bit to set
                                   // it to 1 and returns true
  return true;
}

bool code_clr_bit(Code *c, uint32_t i) {
  if (i > c->top) { // returns false if the inputted index is greater than the
                    // value of top
    return false;
  }
  uint32_t temp_i = i; // divides the inputted index i by 8 to find the specific
                       // byte that the index is in and modulo the specified
                       // index by 8 to find the specific bit the index is in
  uint8_t byte = i / 8;
  uint8_t bit = temp_i % 8;
  c->bits[byte] &=
      ~(1UL << (bit)); // bitwise and shifts the desired bit then inverses the
                       // result to set it to 0 and returns true
  return true;
}

bool code_get_bit(Code *c, uint32_t i) {
  if (i > c->top) { // returns false if the inputted index is greater than the
                    // value of top
    return false;
  }
  uint32_t temp_i = i; // divides the inputted index i by 8 to find the specific
                       // byte that the index is in and modulo the specified
                       // index by 8 to find the specific bit the index is in
  uint8_t byte = i / 8;
  uint8_t bit = temp_i % 8;
  uint8_t temp = c->bits[byte];
  uint8_t temp2 =
      temp; // make a copy of the temp variable above to compare it to the
            // original. I will shift temp and keep temp2 how it was perviously
            // and if they equal each other then the bit was a 1 and returns
            // true. If they do not equal each other then that means the bit is
            // a 0 and returns false
  temp |= 1UL << (bit);
  if (temp == temp2) {
    return true;
  } else if (temp != temp2) {
    return false;
  }
  return false;
}

bool code_push_bit(Code *c, uint8_t bit) {
  if (code_full(c) == true) { // if the code bits array is full, returns false
    return false;
  }
  if (bit ==
      1) { // if the inputted bit is 1 and set bit returns true then increment
           // the top variable and return true, else return false
    if (code_set_bit(c, c->top) == true) {
      c->top += 1;
      return true;
    } else {
      return false;
    }
  }
  if (bit ==
      0) { // if the inputted bit is 0 and clear bit returns true then increment
           // the top variable and return true, else return false
    if (code_clr_bit(c, c->top) == true) {
      c->top += 1;
      return true;
    } else {
      return false;
    }
  }
  return false;
}

bool code_pop_bit(Code *c, uint8_t *bit) {
  if (code_empty(c) == true) { // if the bits array is empty then return false
    return false;
  }
  if (code_get_bit(c, c->top - 1) ==
      true) { // if get bit equals true then set the inputted bit parameter to 1
    *bit = 1;
  } else if (code_get_bit(c, c->top - 1) ==
             false) { // if get bit equals false then set the inputted bit
                      // para,eter to 0
    *bit = 0;
  }
  if (code_clr_bit(c, c->top - 1) ==
      true) { // if clear bit returns true then decrement the top and return
              // true
    c->top -= 1;
    return true;
  }
  return false; // return false if the progra, falls to the bottom of the
                // function because that means there was a problem and a bit
                // wasnt popped
}

void code_print(Code *c) {
  uint32_t len =
      code_size(c); // gets the length of the bits array and loops through the
                    // bits array with the specified amount
  for (uint32_t i = 0; i < len; i += 1) {
    if (code_get_bit(c, i) == true) { // prints a 1 if get bit returned true and
                                      // a 0 if it returned false
      printf("1\n");
    } else if (code_get_bit(c, i) == false) {
      printf("0\n");
    }
  }
}
