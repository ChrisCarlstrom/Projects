#include "code.h"
#include "defines.h"
#include "header.h"
#include "heap.h"
#include "huffman.h"
#include "io.h"
#include "node.h"
#include "pq.h"
#include "stack.h"
#include <fcntl.h>
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#define OPTIONS "hi:o:v"

Code pass; // the same variable that was used in write codes needs to be
           // intialized here again

int main(int argc, char **argv) {

  int opt = 0;               // option counter
  int openin = STDIN_FILENO; // initializes the infile as stdin, can be changed
                             // if the user inputs a file
  int openout = STDOUT_FILENO; // initializes the outfile as stdout, can be
                               // changed if the user inputs a file
  bool stats = false; // sets the stats variable to false, can be changed if
                      // user asks for stats

  while ((opt = getopt(argc, argv, OPTIONS)) !=
         -1) { // while there are more options
    switch (opt) {
    case 'h': // print the help message to stderr
      fprintf(stderr, "SYNOPSIS\n");
      fprintf(stderr, "  A Huffman decoder.\n");
      fprintf(stderr,
              "  Decompresses a file using the Huffman coding algorithm.\n");
      fprintf(stderr, "\n");
      fprintf(stderr, "USAGE\n");
      fprintf(stderr, "  ./decode [-h] [-i infile] [-o outfile]\n");
      fprintf(stderr, "\n");
      fprintf(stderr, "OPTIONS\n");
      fprintf(stderr, "  -h             Program usage and help.\n");
      fprintf(stderr, "  -v             Print compression statistics.\n");
      fprintf(stderr, "  -i infile      Input file to decompress.\n");
      fprintf(stderr, "  -o outfile     Output of decompressed data.\n");
      return 0;

    case 'i':
      openin =
          open(optarg, O_RDONLY); // if the user inputs an infile then it will
                                  // replace stdin and be opened for reading
      break;

    case 'o':
      openout = open(
          optarg, O_WRONLY,
          O_CREAT); // if user inputs an outfile it replaces stdout and if the
                    // file they entered has not been created the program will
                    // create the outfile, it will open the file for writing
      break;

    case 'v':
      stats = true; // sets the stats boolean to true
      break;

    default: // prints the help message
      fprintf(stderr, "SYNOPSIS\n");
      fprintf(stderr, "  A Huffman decoder.\n");
      fprintf(stderr,
              "  Decompresses a file using the Huffman coding algorithm.\n");
      fprintf(stderr, "\n");
      fprintf(stderr, "USAGE\n");
      fprintf(stderr, "  ./decode [-h] [-i infile] [-o outfile]\n");
      fprintf(stderr, "\n");
      fprintf(stderr, "OPTIONS\n");
      fprintf(stderr, "  -h             Program usage and help.\n");
      fprintf(stderr, "  -v             Print compression statistics.\n");
      fprintf(stderr, "  -i infile      Input file to decompress.\n");
      fprintf(stderr, "  -o outfile     Output of decompressed data.\n");
      return 1;
    }
  }
  Header head; // creates a new header object to read in and store the
               // information from the infile
  uint8_t buf1[16]; // creates an array to hold all of the header object's
                    // fields
  read_bytes(openin, buf1, 16); // reads the first 16 bytes of the infile, which
                                // is the length of the header
  memcpy(&head.magic, buf1,
         4); // use memcopy to save the first 4 bytes of buf1 into the header
             // object's magic field(4 bytes because magic is a uint32_t)
  if (head.magic !=
      MAGIC) { // if the magic numbers don't match then return an error
    fprintf(stderr, "could not verify magic number\n");
    return 1;
  }
  memcpy(&head.permissions, buf1 + 4,
         2); // copy the permissions of the header into the header objects
             // permissions field and use those permissions to alter the
             // permissions of the outfile. Then grab the tree size and file
             // size from the infile and store them in the correct fields, again
             // since the tree size is a uint16_t and the file_size is a
             // uint64_t we will grab the next 2 bytes and 8 bytes respectively
  fchmod(openout, head.permissions);
  memcpy(&head.tree_size, buf1 + 6, 2);
  memcpy(&head.file_size, buf1 + 8, 8);

  uint8_t
      tree_dump[head.tree_size]; // create a trr_dump array to hold the contents
                                 // from the dump_tree funtion that we used in
                                 // encode.c and another array that holds 1
                                 // element to read byte by byte
  uint8_t temp1[1];
  uint32_t i = 0;
  while (i <
         head.tree_size) { // loop while a count is less than the tree_size and
                           // read in a byte at a time, checking if the read
                           // call ever returns 0, if it does that means there
                           // is no more bytes to be read. While the loop is
                           // going it will increment the extern variable and
                           // set the byte that it read(which is currently in
                           // the temp1 buffer), in the tree_dump array at the
                           // count's index, then will increment the count. This
                           // will continue until the entire dump_tree contents
                           // is written in the tree_dump array
    int j = read(openin, temp1, 1);
    if (j == 0) {
      break;
    }
    bytes_read += 1;
    tree_dump[i] = temp1[0];
    temp1[0] = 0;
    i += 1;
  }
  Node *root = rebuild_tree(
      head.tree_size, tree_dump); // call rebuild tree and create a root pointer
                                  // that equals what rebuild tree returns
  uint64_t count = bytes_written; // create a count to use to track how long the
                                  // loop shoud iterate for
  Node *current = root; // initialize a pointer to the root node and create a
                        // buffer to hold a byte at a time
  uint8_t buf2[1];
  while (
      count !=
      head.file_size) { // while bytes_written doesnt equal the file size we
                        // want to read the next bit that is in the infile and
                        // save that bit in the variable called bit, next we
                        // check if the bit is a 1 or a 0, if it is a 0 then we
                        // want to travel down the left side of the tree, or
                        // down the current node's left pointer. We then check
                        // if the new current node's left and right node
                        // pointers are NULL i, if one or both of the pointers
                        // are not NULL then we just continue, but if they are
                        // then we want to add the node's symbol to our buffer
                        // and write it to the outfile. We then reset the
                        // current pointer back to the root and increment the
                        // count to start back at the root of the tree. If the
                        // bit is a 1 then we want to travel down the right side
                        // of the tree, or down the current node's right
                        // pointer. We then check if the new current node's left
                        // and right node pointers are NULL i, if one or both of
                        // the pointers are not NULL then we just continue, but
                        // if they are then we want to add the node's symbol to
                        // our buffer and write it to the outfile. We then reset
                        // the current pointer back to the root and increment
                        // the count to start back at the root of the tree.
    uint8_t bit = 0;
    if (read_bit(openin, &bit) == true) {
      if (bit == 0) {
        current = current->left;
        if (current->left == NULL && current->right == NULL) {
          buf2[0] = current->symbol;
          write_bytes(openout, buf2, 1);
          current = root;
          count += 1;
        }
      } else if (bit == 1) {
        current = current->right;
        if (current->left == NULL && current->right == NULL) {
          buf2[0] = current->symbol;
          write_bytes(openout, buf2, 1);
          current = root;
          count += 1;
        }
      }
    }
  }

  if (stats == true) { // if the user asks for the stats then the program will
                       // print the stat information
    fprintf(stderr, "Compressed file size: %lu bytes\n", bytes_read);
    fprintf(stderr, "Decompressed file size: %lu bytes\n", bytes_written);
    float savings = (100 * (1 - ((float)bytes_read) / (float)bytes_written));
    fprintf(stderr, "Space saving: %.2f%%\n", savings);
  }

  close(openin); // close the infile and outfile and delete the tree and return
  close(openout);
  delete_tree(&root);

  return 0;
}
