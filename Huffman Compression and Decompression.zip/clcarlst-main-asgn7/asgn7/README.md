To build the code you must have the following files in a folder: encode.c, decode.c, defines.h, header.h, node.h, node.c, pq.h, pq.c, code.h, code.c, io.h, io.c, stack.h, stack.c, huffman.h, huffman.c, heap.h, heap.c, and Makefile. To compile the code you need to be in a terminal with all of the files and type 'make' to build the program and compile the code. You then must type './encode' with any of the command line options you want(listed below). You then must type './decode' along with any of the command line options(listed below) to decode the file.




Command line options for ./encode:

-h: Prints out a help message describing the purpose of the program and the command-line op-
tions it accepts, exiting the program afterwards. Refer to the reference program provided to you,
for an idea of what to print.

-i infile: Specifies the input file to encode using Huffman coding. The default input should be
set as stdin.

-o outfile: Specifies the output file to write the compressed input to. The default output should
be set as stdout.

-v: Prints compression statistics to stderr. These statistics include the uncompressed file size,
the compressed file size, and space saving.




Command line options for ./decode:

-h: Prints out a help message describing the purpose of the program and the command-line op-
tions it accepts, exiting the program afterwards. Refer to the reference program provided to you,
for an idea of what to print.

-i infile: Specifies the input file to decode using Huffman coding. The default input should be
set as stdin.

-o outfile: Specifies the output file to write the decompressed input to. The default output
should be set as stdout.

-v: Prints decompression statistics to stderr. These statistics include the compressed file size,
the decompressed file size, and space saving.





List of files in this assignment:

1. encode.c: This file contains your implementation of the Huffman encoder.

2. decode.c: This file contains your implementation of the Huffman decoder.

3. defines.h: This file contains the macro definitions used throughout the assignment.

4. header.h: This file contains the struct definition for a file header.

5. node.h: This file contains the node ADT interface.

6. node.c: This file contains your implementation of the node ADT.

7. pq.h: This file contains the priority queue ADT interface.

8. pq.c: This file contains your implementation of the priority queue ADT.

9. code.h: This file contains the code ADT interface.

10. code.c: This file contains your implementation of the code ADT.

11. io.h: This file contains the I/O module interface.

12. io.c: This file contains your implementation of the I/O module.

13. stack.h: This file contains the stack ADT interface.

14. stack.c: This file contains your implementation of the stack ADT.

15. huffman.h: This file contains the Huffman coding module interface.

16. huffman.c: This file contains the implementation of the Huffman coding module interface.

17. heap.h: This file contains the heap interface.

18. heap.c: This file contains the implementation of the heap sorting functions used.

19. Makefile: This is a file that will allow the grader to type make to compile your program.

20. README.md: This must describe how to build and run your program. This includes listing and explaining the command-line options that your program accepts.

21. DESIGN.pdf: The design document should describe your design for your program with enough detail that a sufficiently knowledgeable programmer would be able to replicate your implementation.




False positive scan build errors:

decode.c:112:8: warning: Access to field 'left' results in a dereference of a null pointer (loaded from variable 'current') [core.NullDereference]
                                if(current->left == NULL && current->right == NULL){

This is a false posititve beacuse we need to dereference the NULL pointer to see if a node has any children or not. This check is necessary to determine if we have found a leaf node or not.


