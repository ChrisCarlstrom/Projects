#include "io.h"
#include "code.h"
#include "defines.h"
#include "heap.h"
#include "node.h"
#include "pq.h"
#include "stack.h"
#include <fcntl.h>
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

extern uint64_t bytes_read; // declare and initialize the extern variables that
                            // will be used to track statistics
uint64_t bytes_read;
extern uint64_t bytes_written;
uint64_t bytes_written;

static uint8_t
    buffer1[BLOCK]; // initialize 2 static variables for read_bit and 2 more for
                    // write_codes, these are static because what they contain
                    // should persist across several function calls and if they
                    // are looped, we don't want these to reset because we want
                    // to have a buffer that has elements that don't change and
                    // we want to have an index that we can save for future
                    // calls to know where we left off previouly and not start
                    // over
static uint32_t index1;
static uint8_t buffer2[BLOCK];
static uint32_t index2;

int read_bytes(int infile, uint8_t *buf, int nbytes) {
  int temp = 0; // initialize temp to store the total number of bytes read in
                // the function call
  int actread =
      1; // this is the variable that is used in the read call and holds the
         // value of how many bytes the read function added to the buffer
  while (temp != nbytes ||
         actread !=
             0) { // loops while the total number of bytes read does not equal
                  // the inputted nbytes value, meaning that the function should
                  // read more bytes, or if actread equals zero, meaning that it
                  // has come to the end of the file
    actread = 0;
    int check =
        nbytes -
        temp; // this checks if the read function should read a full block of
              // bytes meaning that there are more than 4096 bytes still
              // reamining that need to be read in or if there is less, if there
              // is less then it will change the BLOCK in the count parameter of
              // the read call to the check value to read the proper amount and
              // not read over the specified amount
    if (check >=
        BLOCK) { // checks whether there are more or less than 4096 bytes to be
                 // read and picks the correct read call based on that
      actread =
          read(infile, buf, BLOCK); // the read call for if there is over 4096
                                    // bytes that still need to be read
      if (actread <=
          0) { // breaks if the read call reaches an end of file or an error
        break;
      }
    } else if (check < BLOCK) {
      actread =
          read(infile, buf, check); // the read call for if there is less than
                                    // 4096 bytes that still need to be read
      if (actread <=
          0) { // breaks if the read call reaches an end of file or an error
        break;
      }
    }
    temp += actread; // adds what was actually read in the current iteration to
                     // the total read for this function call
    bytes_read += actread; // adds the amount of bytes read in this iteration to
                           // the extern variable
  }
  return temp; // returns the amount of bytes that were read from the function
               // call, either the nbytes specified amount or less if it reached
               // and EOF
}

int write_bytes(int outfile, uint8_t *buf, int nbytes) {
  int temp = 0; // initialize temp to store the total number of bytes written in
                // the function call
  int actwrote =
      1; // this is the variable that is used in the write call and holds the
         // value of how many bytes the write function added to the outfile
  while (temp != nbytes ||
         actwrote ==
             0) { // loops while the total number of bytes written does not
                  // equal the inputted nbytes value, meaning that the function
                  // should write more bytes, or if actwrote equals zero,
                  // meaning that it has emptied the buffer
    actwrote = 0;
    int check =
        nbytes -
        temp; // this checks if the write function should write a full block of
              // bytes meaning that there are more than 4096 bytes still
              // reamining that need to be written in or if there is less, if
              // there is less then it will change the BLOCK in the count
              // parameter of the write call to the check value to write the
              // proper amount and not write over the specified amount
    if (check >=
        BLOCK) { // checks whether there are more or less than 4096 bytes to be
                 // written and picks the correct write call based on that
      actwrote = write(outfile, buf,
                       BLOCK); // the write call for if there is over 4096 bytes
                               // that still need to be written
      if (actwrote <=
          0) { // breaks if the read call reaches an end of file or an error
        break;
      }
    } else if (check < BLOCK) {
      actwrote = write(outfile, buf,
                       check); // the write call for if there is less than 4096
                               // bytes that still need to be written
      if (actwrote <=
          0) { // breaks if the read call reaches an end of file or an error
        break;
      }
    }
    temp += actwrote; // adds what was actually written in the current iteration
                      // to the total written for this function call
    bytes_written += actwrote; // adds the amount of bytes written in this
                               // iteration to the extern variable
  }
  return temp; // returns the amount of bytes that were written from the
               // function call, either the nbytes specified amount or less if
               // it reached and EOF
}

bool read_bit(int infile, uint8_t *bit) {
  if (index1 == (BLOCK * 8) ||
      index1 == 0) { // checks if the index has reached the end of the buffer,
                     // if it has then it resets the buffer to all 0's, we check
                     // BLOCK * 8 because we are indexing through bits and using
                     // uint8_t's so there are 8 bits per byte
    for (uint32_t i = 0; i < BLOCK; i += 1) {
      buffer1[i] = 0;
    }
  }
  if (index1 == (BLOCK * 8) ||
      index1 == 0) { // checks if the index has reached the end of the buffer
                     // again, it it has it will fill a new buffer to be read,
                     // however if the read_bytes function call returns 0 then
                     // the read_bit function will return false meaning that
                     // there are no more bits tp be read
    int go_to = read_bytes(infile, buffer1, BLOCK);
    if (go_to == 0) {
      return false;
    }
    index1 = 0; // resets the index if a new buffer is filled so that the
                // function will start at the beginning of the buffer again
  }
  uint32_t temp_index = index1; // we are essentially copying our get bit
                                // function from code.c here
  uint32_t curr_byte =
      index1 / 8; // find the byte that the current index is located in, this is
                  // index / 8 beacuse we are using uint8_t's
  uint32_t curr_bit =
      temp_index % 8; // finds the exact bit where the index is, again doing
                      // index % 8 beacuse we are using uint8_t's
  uint8_t temp =
      buffer1[curr_byte]; // saves two copies of this in temp and temp2 to
                          // compare against each other, it bitwise or shifts
                          // the current index bit of temp and checks if it
                          // equal to temp2, if yes then it sets the bit in the
                          // function parameter to 1, if they dont equal then it
                          // sets the parameter bit to 0, in either case the
                          // index will increment and return true beacuse there
                          // was another bit to be read
  uint8_t temp2 = temp;
  temp |= 1UL << (curr_bit);
  if (temp == temp2) {
    *bit = 1;
  } else if (temp != temp2) {
    *bit = 0;
  }
  index1 += 1;
  return true;
}

void write_code(int outfile, Code *c) {
  uint32_t count = 0; // initializes a count to be used to loop though the code
                      // bits array while it less than the size of the code
  while (count < code_size(c)) {
    if (index2 ==
        (BLOCK *
         8)) { // if the index is equal to the size of the BLOCK * 8, it will
               // write the bits that are in the buffer to the outfile and zero
               // out the buffer array to reset it, it will also reset the index
      write_bytes(outfile, buffer2, BLOCK);
      for (uint32_t i = 0; i < BLOCK; i += 1) {
        buffer2[i] = 0;
        index2 = 0;
      }
    }
    if (code_get_bit(c, count) ==
        true) { // if the buffer does not need to be written to the outfile
                // because it is not full yet then it will get the bit of the
                // current iteration, if it is true, meaning that the bit is a
                // 1, then it will bitwise or shift the bit of the current index
                // of the buffer array to set it to 1, increment the count and
                // the index
      uint32_t temp_index = index2;
      uint32_t curr_byte = index2 / 8;
      uint32_t curr_bit = temp_index % 8;
      buffer2[curr_byte] |= (1UL << (curr_bit));
      count += 1;
      index2 += 1;
    } else if (code_get_bit(c, count) ==
               false) { // if get bit returned false, meaning that the bit is a
                        // 0 then it will simply do nothing beacuse the bits in
                        // the buffer are 0 already because they were zeroed out
                        // at the beginning, however it will still increment the
                        // count and current index of the buffer
      count += 1;
      index2 += 1;
    }
  }
}

void flush_codes(
    int outfile) { // this calls write_bytes to write the remaining bytes that
                   // were left over in the buffer if the buffer was not able to
                   // fill up and clear itself, it also checks if the the amount
                   // that should be written is even or odd because if it is odd
                   // then floor division will round it down, meaning that if
                   // the number is odd it will detect that and add 1 more byte
                   // to be written to account for the missing byte
  ((index2 / 8) % 8 != 0) ? (write_bytes(outfile, buffer2, ((index2 / 8) + 1)))
                          : (write_bytes(outfile, buffer2, (index2 / 8)));
}
