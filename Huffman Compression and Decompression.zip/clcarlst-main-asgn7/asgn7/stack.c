#include "stack.h"
#include "code.h"
#include "defines.h"
#include "heap.h"
#include "node.h"
#include "pq.h"
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

typedef struct Stack { // initialize stack struct with fields top, capacity, and
                       // items array
  uint32_t top;
  uint32_t capacity;
  Node **items;
} Stack;

Stack *stack_create(uint32_t capacity) {
  Stack *s = (Stack *)malloc(
      sizeof(Stack)); // create a stack and check if it was created correctly
  if (s) {
    s->top = 0; // if it was created correctly created set the stack's top to 0,
                // set the stack's capacity to inputted capacity
    s->capacity = capacity;
    s->items = (Node **)calloc(
        capacity,
        sizeof(Node *)); // calloc the items array to hold nodes inside with
                         // capacity as the size of the array
    if (s->items == NULL) { // if the items array was not created correctly then
                            // free the array and set it to NULL
      free(s);
      s = NULL;
    }
  } else { // if the stack was not properly created then free the stack and set
           // it to NULL
    free(s);
    s = NULL;
  }
  return s;
}

void stack_delete(Stack **s) {
  if ((*s) == NULL) { // check if the stack is NULL, is yes then just return
    return;
  }
  if ((*s)->items != NULL) { // if the items array in the stack object is not
                             // NULL, free the items array and set it to NULL
    free((*s)->items);
    (*s)->items = NULL;
  }
  free((*s)); // free the stack object and set it to NULL
  (*s) = NULL;
}

bool stack_empty(Stack *s) {
  if (s != NULL) { // check if the stack object is not NULL, if yes then return
                   // true if the top field is 0 else return false
    if (s->top == 0) {
      return true;
    }
  }
  return false;
}

bool stack_full(Stack *s) {
  if (s != NULL) { // same as above except return true if top is equal to the
                   // capacity and false otherwise
    if (s->top == s->capacity) {
      return true;
    }
  }
  return false;
}

uint32_t stack_size(Stack *s) {
  return s->top; // returns the value of the stack object's top field
}

bool stack_push(Stack *s, Node *n) {
  if (s == NULL) { // if the stack object is NULL or if it is full, return false
    return false;
  }
  if (stack_full(s) == true) {
    return false;
  }
  s->items[s->top] = n; // otherwise push the inputted node to the index of top
                        // and increment the top, returning true
  s->top += 1;
  return true;
}

bool stack_pop(Stack *s, Node **n) {
  if (s == NULL) { // if the stack object is NULL or if it is full, return false
    return false;
  }
  if (stack_empty(s) == true) {
    return false;
  }
  (*n) =
      s->items[s->top - 1]; // sets a node pointer to the top value of the
                            // stack, this is to be passed out of the function
  s->items[s->top - 1] = NULL; // set the top vaue of the stack to NULL and
                               // decrements the top field by 1 and return true
  s->top -= 1;
  return true;
}

void stack_print(Stack *s) {
  if (s == NULL) { // if the stack object is NULL then just return
    return;
  }
  for (uint32_t i = 0; i < stack_size(s);
       i += 1) { // loops through the size of the stack and prints all of the
                 // nodes in the items array
    node_print(s->items[i]);
  }
}
