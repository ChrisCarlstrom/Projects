#include <stdio.h>
#include <inttypes.h>
#include "node.h"


void node_swap(Node *one, Node *two);


void up_heap(Node **arr, uint32_t n);


void down_heap(Node **arr, uint32_t heap_size);


