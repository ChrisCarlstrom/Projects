#include "code.h"
#include "defines.h"
#include "header.h"
#include "heap.h"
#include "huffman.h"
#include "io.h"
#include "node.h"
#include "pq.h"
#include "stack.h"
#include <fcntl.h>
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#define OPTIONS "hi:o:v"

Code pass; // initialize variale to be used in build codes

int main(int argc, char **argv) {

  int opt = 0;        // option counter
  pass = code_init(); // initialize pass variable, this will be used in
                      // huffman.c as an extern variable for build_codes
  int openin = STDIN_FILENO; // initialize file int to stdin, can be changed by
                             // user input
  int openout = STDOUT_FILENO; // initialize file int to stdout, can be changed
                               // by the user
  bool stats = false; // set the stat variable to false
  bool s_in =
      true; // set stdin variable to true since stdin is infile by default

  while ((opt = getopt(argc, argv, OPTIONS)) !=
         -1) { // while there are more options
    switch (opt) {
    case 'h': // prints the help message
      fprintf(stderr, "SYNOPSIS\n");
      fprintf(stderr, "  A Huffman encoder.\n");
      fprintf(stderr,
              "  Compresses a file using the Huffman coding algorithm.\n");
      fprintf(stderr, "\n");
      fprintf(stderr, "USAGE\n");
      fprintf(stderr, "  ./encode [-h] [-i infile] [-o outfile]\n");
      fprintf(stderr, "\n");
      fprintf(stderr, "OPTIONS\n");
      fprintf(stderr, "  -h             Program usage and help.\n");
      fprintf(stderr, "  -v             Print compression statistics.\n");
      fprintf(stderr, "  -i infile      Input file to compress.\n");
      fprintf(stderr, "  -o outfile     Output of compressed data.\n");
      return 0;

    case 'i':
      openin = open(optarg, O_RDONLY); // sets the user inputted file to the
                                       // infile, replacing stdin
      break;

    case 'o':
      openout =
          open(optarg, O_WRONLY, O_CREAT); // sets the user inputted file to the
                                           // outfile, replacing stdout
      break;

    case 'v':
      stats = true; // sets the stat boolean to true
      break;

    default:
      fprintf(stderr, "SYNOPSIS\n"); // prints the help message and returns
                                     // error
      fprintf(stderr, "  A Huffman encoder.\n");
      fprintf(stderr,
              "  Compresses a file using the Huffman coding algorithm.\n");
      fprintf(stderr, "\n");
      fprintf(stderr, "USAGE\n");
      fprintf(stderr, "  ./encode [-h] [-i infile] [-o outfile]\n");
      fprintf(stderr, "\n");
      fprintf(stderr, "OPTIONS\n");
      fprintf(stderr, "  -h             Program usage and help.\n");
      fprintf(stderr, "  -v             Print compression statistics.\n");
      fprintf(stderr, "  -i infile      Input file to compress.\n");
      fprintf(stderr, "  -o outfile     Output of compressed data.\n");
      return 1;
    }
  }
  if (openin !=
      STDIN_FILENO) { // checks if a file was passed in by the user, if a file
                      // was passed in then the program will set the stdin
                      // boolean to false so the program knows to skip over the
                      // section that takes place if the user wants to use
                      // stdin(will describe how that works later)
    s_in = false;
  }
  Header head; // initialize a new header to hold all of the different fields
               // that header contains that will be written in the outfile
  head.magic =
      MAGIC; // set the MAGIC macro number to the header's magic number, then
             // craetes a stat object to check the permissions of the infile, we
             // do this so we can set the permissions to the permissions fieled
             // in the header object so that decode's outfile can have the same
             // permissions, we also want to change encode's permissions to
             // match so that the file contents can be properly encoded and
             // decoded
  struct stat perms;
  fstat(openin, &perms);
  head.permissions = perms.st_mode;
  fchmod(openout, perms.st_mode);
  static uint8_t buf1[1]; // create a buffer that holds 1 byte so we can read 1
                          // element at a time and another buffer to act as our
                          // histogram taht will be used in later functions
  static uint64_t buf2[ALPHABET];
  if (s_in ==
      true) { // if the user wants to use stdin to enter what they would like
              // encoded, then we must create a temp file to store all of the
              // conents in stdin. After the user has entered what they want to
              // be encoded the program will read in the bytes from stdin 1 by 1
              // until thee is nothing more to read and will add the contents of
              // stdin to the temp file 1 by 1
    int tempf = open("t_file", O_CREAT | O_TRUNC | O_RDWR);
    while (read_bytes(openin, buf1, 1) != 0) {
      write_bytes(tempf, buf1, 1);
    }
    openin = tempf; // the temp file then becomes the openin variable so that
                    // the rest of the code can be used and we don't need two
                    // copies of the same code, we also want to reset the bytes
                    // written because if we don't then the stats will be off
                    // because we will be reading again later, lastly we want to
                    // use lseek on the file so that we can start at the
                    // beginning again beacuse after writing all of the contents
                    // of stdin to the temp file, the program would continue at
                    // the end of the file when we want to call a read function
                    // on the file and not actually read what is in the file
    bytes_written = 0;
    lseek(openin, 0, SEEK_SET);
  }
  fstat(openin, &perms);
  while (read_bytes(openin, buf1, 1) !=
         0) { // now we read in the bytes from the infile(doesnt matter if the
              // user inputted a file or used stdin because all of the contents
              // from stdin was added to a file) 1 by 1 and add 1 to the ascii
              // value of the current element that is in buf1, we then zero out
              // buf1 to reset it for the next element in the infile
    uint8_t temp = buf1[0];
    buf2[temp] += 1;
    buf1[0] = 0;
  }
  if (buf2[0] == 0) { // we set the first 2 indicies to 1 if they are zero to
                      // ensure that we at least have something in our histogram
                      // so that a tree can be made no matter what
    buf2[0] = 1;
  }
  if (buf2[1] == 0) {
    buf2[1] = 1;
  }
  Node *root = build_tree(buf2); // build the tree to get the root of the tree
  Code table[ALPHABET]; // initialize an array of codes and set every element to
                        // a code, the code array hold ALPHABET number of code
                        // objects, each index for a different symbol that could
                        // be in the message
  for (uint32_t i = 0; i < ALPHABET; i += 1) {
    table[i] = code_init();
  }
  build_codes(root,
              table); // call build codes to get the codes of our huffman tree
  uint16_t count =
      0; // use this count to find the number of leaves in the tree to calculate
         // the tree size of the huffman tree, we loop through the histogram and
         // count how many nonzero indicied there are, then do the tree_size
         // calculation below
  for (uint16_t j = 0; j < ALPHABET; j += 1) {
    if (buf2[j] != 0) {
      count += 1;
    }
  }
  head.tree_size = ((3 * count) - 1);
  head.file_size =
      perms.st_size; // get the size of the file so that we can use it as a
                     // condition in a loop in decode to read the entire file
  uint8_t new_buf[sizeof(
      head)]; // we want to flattern the header object into a uint8_t bit array
              // so that we can write it to the outfile, we make a new buffer to
              // contain all of the different fields of a header and copy the
              // data into the new buffer, after we copy all of the data we
              // write the header to the outfile
  memcpy(new_buf, &head, sizeof(head));
  write_bytes(openout, new_buf, sizeof(Header));
  dump_tree(openout,
            root); // call dump tree to write the entire huffman tree to the
                   // outfile and use lseek again on the infile to go to the
                   // beginning of the file so we can write the codes for each
                   // for each of the nodes into the outfile
  lseek(openin, 0, SEEK_SET);
  static uint8_t buf3[1];
  bytes_read = 0; // reset the bytes_read extern variable so we don't improperly
                  // track the stats
  while (read_bytes(openin, buf3, 1) !=
         0) { // we loop through the infile again with a buffer that stores 1
              // element again to read byte by byte and write the code of each
              // letter into the code array, then write the code array to the
              // outfile
    uint8_t temp2 = buf3[0];
    write_code(openout, &table[temp2]);
  }
  flush_codes(openout); // flush the codes to make sure that all of the codes
                        // are in the outfile eveen if we weren't able to fill
                        // teh buffer at the end
  if (stats == true) { // if the user wanted to see the stats then print all of
                       // the stats data
    fprintf(stderr, "Uncompressed file size: %lu bytes\n", bytes_read);
    fprintf(stderr, "Compressed file size: %lu bytes\n", bytes_written);
    float savings = (100 * (1 - ((float)bytes_written / (float)bytes_read)));
    fprintf(stderr, "Space saving: %.2f%%\n", savings);
  }
  if (s_in) { // if stdin was used then we need to delete the temp file that was
              // made
    remove("t_file");
  }
  close(openin); // close the infile and outfile and delete the tree then return
  close(openout);
  delete_tree(&root);

  return 0;
}
