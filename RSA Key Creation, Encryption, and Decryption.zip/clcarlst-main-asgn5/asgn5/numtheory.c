#include <stdio.h>
#include <gmp.h>
#include <stdbool.h>
#include <inttypes.h>
#include "randstate.h"



void gcd(mpz_t d, mpz_t a, mpz_t b){
	mpz_t t;//initialize variables
	mpz_t temp_a;
	mpz_t temp_b;
	mpz_init_set(temp_a, a);//set temp_a to a
	mpz_init_set(temp_b, b);//set temp_b to b
	mpz_init(t);
	while(mpz_cmp_ui(temp_b, 0) != 0){//loops while temp_b doesnt equal 0
		mpz_set(t, temp_b);//sets temp_b to t
		mpz_mod(temp_b, temp_a, temp_b);//sets temp_b % temp_a to temp_b
		mpz_set(temp_a, t);//sets t to temp_a
	}
	mpz_set (d, temp_a);//sets temp_a to out
	mpz_clears(t, temp_a, temp_b, NULL);//clears initialized variables
	//gmp_printf("%Zu\n", d);
}



void pow_mod(mpz_t out, mpz_t base, mpz_t exponent, mpz_t modulus){
	
	mpz_t v;//initialize variables
	mpz_t p;
	mpz_t temp;
	mpz_t temp2;

	mpz_init_set_ui(v, 1);//sets v to 1
	mpz_init_set(p, base);//sets p to base
	mpz_init_set(temp, exponent);//sets temp to exponent
	mpz_init(temp2);

	while(mpz_cmp_ui(temp, 0) != 0){//loops while temp is greater than 0
		if(mpz_odd_p(temp)){//checks if temp is odd
			mpz_mul(v, v, p);//multiply v and p
			mpz_mod(v, v, modulus);//set v to result % modulus
		}

		mpz_mul(temp2, p, p);//square p
		mpz_mod(p, temp2, modulus);//take modulus of p
		mpz_fdiv_q_ui(temp, temp, 2);//divide temp by 2
	}
	mpz_set(out, v);//sets v to out
	mpz_clears(v, p, temp, temp2, NULL);//clear initialized variables
	//gmp_printf("%Zu\n", out);
}




bool is_prime(mpz_t n, uint64_t iters){

	if ((mpz_cmp_ui(n, 1) == 0) || (mpz_cmp_ui(n, 2) == 0) || (mpz_cmp_ui(n, 3) == 0)){
		return true;//base cases for 123
	}

	mpz_t s;//initialize variables and set some to certain values
	mpz_init_set_ui(s, 0);

	mpz_t r;
	mpz_init(r);
	mpz_sub_ui(r, n, 1);

	mpz_t y;
	mpz_init(y);

	mpz_t a;
	mpz_init(a);

	mpz_t j;
	mpz_init(j);

	mpz_t temp1;
	mpz_init(temp1);
	mpz_sub_ui(temp1, n, 3);

	mpz_t r2;
	mpz_init(r2);
	mpz_sub_ui(r2, n, 1);

	mpz_t temp3;
	mpz_init(temp3);



	while(mpz_odd_p(r) == 0){//while r is even
		mpz_fdiv_q_ui(r, r, 2);//divide r by 2
		mpz_add_ui(s, s, 1);//add 1 to s
	}
	
	mpz_t s2;//initialize more variables
	mpz_init(s2);
	mpz_sub_ui(s2, s, 1);

	mpz_t temp2;
	mpz_init_set_ui(temp2, 2);

	for(uint64_t i = 1; i <= iters; i += 1){//loop through iters 
		mpz_urandomm(a, state, temp1);//create a random number and set to a
		mpz_add_ui(a, a, 2);//add 2 to a
		pow_mod(y, a, r, n);//call power mod and store result in y
		if((mpz_cmp_ui(y, 1) != 0) && (mpz_cmp(y, r2) != 0)){//checks if y doesnt equal 1 and r2
			mpz_set_ui(j, 1);//set j to 1
			while((mpz_cmp(j, s2) < 1) && (mpz_cmp(y, r2) != 0)){//while j is less than s-1 and y doesnt equal r2
				pow_mod(temp3, y, temp2, n);//call pow_mod and store result in temp3
				if(mpz_cmp_ui(temp3, 1) == 0){//if y = 1
					mpz_clears(s, s2, r, r2, y, a, j, temp1, temp2, temp3, NULL);//clear initialized variables and return false
					//printf("false\n");
					return false;
				}
				mpz_add_ui(j, j, 1);//add 1 to j
			}
			if(mpz_cmp(temp3, r2) != 0){//checks if y doesnt equal r2
				mpz_clears(s, s2, r, r2, y, a, j, temp1, temp2, temp3, NULL);//clears variables and returns false
				//printf("false\n");
				return false;
			}
		}
	}
	mpz_clears(s, s2, r, r2, y, a, j, temp1, temp2, temp3, NULL);//clears variables and returns true
	//printf("true\n");
	return true;
}




void mod_inverse(mpz_t i, mpz_t a, mpz_t n){
	
	mpz_t r;//initialize variables and set some to certain values
	mpz_init_set(r, n);

	mpz_t rp;
	mpz_init_set(rp, a);

	mpz_t t;
	mpz_init_set_ui(t, 0);

	mpz_t tp;
	mpz_init_set_ui(tp, 1);

	mpz_t q;
	mpz_init(q);

	mpz_t r2;
	mpz_init(r2);

	mpz_t t2;
	mpz_init(t2);



	while(mpz_cmp_ui(rp, 0) != 0){//while rp doesnt equal 0
		mpz_set(r2, r);//duplicate of r and t to make math correct
		mpz_set(t2, t);
		mpz_fdiv_q(q, r, rp);//sets q to r/rp
		mpz_set(r, rp);//sets r to rp
		mpz_mul(rp, q, rp);//sets rp equal to q*rp
		mpz_sub(rp, r2, rp);//sets rp equal to r2-rp
		mpz_set(t, tp);//set t equal to tp
		mpz_mul(tp, q, tp);//set tp equal to q*tp
		mpz_sub(tp, t2, tp);//set tp equal to t2-tp
	}
	if(mpz_cmp_ui(r, 1) != 0){//checks if r id greater than 1
		mpz_clears(r, r2, rp, t, t2, tp, q, NULL);//clears initialized variables and returns nothing
		//printf("nope\n");
		return;
	}
	if(mpz_cmp_ui(t, 0) < 0){//checks if t is less than 0
		mpz_add(t, t, n);//add n to t
	}
	mpz_set(i, t);//set i equal to t
	mpz_clears(r, r2, rp, t, t2, tp, q, NULL);//clears initialized variables
	//gmp_printf("%Zu\n", i);
}



void make_prime(mpz_t p, uint64_t bits, uint64_t iters){		
	
	
	while(mpz_sizeinbase(p, 2) < bits || is_prime(p, iters) != true){//if prime is false and p is less than bits long
		mpz_urandomb(p, state, bits);//get random number and store in p
		if(mpz_even_p(p) != 0){//check is p is even
			mpz_sub_ui(p, p, 1);//subtract 1 from p
		}
        }
	return;
}


