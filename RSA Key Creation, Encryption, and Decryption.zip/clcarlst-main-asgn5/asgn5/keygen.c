#include <stdio.h>
#include "rsa.h"
#include "numtheory.h"
#include "randstate.h"
#include <stdlib.h>
#include <inttypes.h>
#include <stdint.h>
#include <stdbool.h>
#include <unistd.h>
#include <time.h>
#include <sys/stat.h>
#include <string.h>
#define OPTIONS "b:i:n:d:s:vh"



int main(int argc, char **argv) {

	time_t time(time_t *seconds);//initialize time

	
	int opt = 0;//option counter
	
	uint64_t nbits = 1024;//initialize default variables and files
	uint64_t iters = 50;
	FILE *pbfile;
	FILE *pvfile;
	char *pub_name = "rsa.pub";
	char *priv_name = "rsa.priv";
	uint64_t seed = time(NULL);
	bool verbose = false;
	char *username;

	
	mpz_t p, q, n, e, d, m, s;//initialize variables
	mpz_inits(p, q, n, e, d, m, s, NULL);


	while ((opt = getopt(argc, argv, OPTIONS)) != -1) {//while there are more options
		switch (opt) {
			case 'b':
				if((strtoul(optarg, NULL, 10) >= 50) && (strtoul(optarg, NULL, 10) <= 4096)){//if bits meets the requirements, replace the default value
					nbits = strtoul(optarg, NULL, 10);
					break;
				}else{//print help message and error
					fprintf(stderr, "Usage: ./keygen [options]\n");
                                	fprintf(stderr, "  ./keygen generates a public / private key pair, placing the keys into the public and private\n");
                                	fprintf(stderr, "  key files as specified below. The keys have a modulus (n) whose length is specified in\n");
                                	fprintf(stderr, "  the program options.\n");
                                	fprintf(stderr, "    -s <seed>   : Use <seed> as the random number seed. Default: time()\n");
                                	fprintf(stderr, "    -b <bits>   : Public modulus n must have at least <bits> bits. Default: 1024\n");
                                	fprintf(stderr, "    -i <iters>  : Run <iters> Miller-Rabin iterations for primality testing. Default: 50\n");
                                	fprintf(stderr, "    -n <pbfile> : Public key file is <pbfile>. Default: rsa.pub\n");
                                	fprintf(stderr, "    -d <pvfile> : Private key file is <pvfile>. Default: rsa.priv\n");
                                	fprintf(stderr, "    -v          : Enable verbose output.\n");
                                	fprintf(stderr, "    -h          : Display program synopsis and usage.\n");
					return 1;
				}

			case 'i':
				if((strtoul(optarg, NULL, 10) >= 1) && (strtoul(optarg, NULL, 10) <= 500)){//if iters meets the requirements, replace the default value
					iters = strtoul(optarg, NULL, 10);
					break;
				}else{//print help message and error
					fprintf(stderr, "Usage: ./keygen [options]\n");
                                	fprintf(stderr, "  ./keygen generates a public / private key pair, placing the keys into the public and private\n");
                                	fprintf(stderr, "  key files as specified below. The keys have a modulus (n) whose length is specified in\n");
                                	fprintf(stderr, "  the program options.\n");
                                	fprintf(stderr, "    -s <seed>   : Use <seed> as the random number seed. Default: time()\n");
                                	fprintf(stderr, "    -b <bits>   : Public modulus n must have at least <bits> bits. Default: 1024\n");
                                	fprintf(stderr, "    -i <iters>  : Run <iters> Miller-Rabin iterations for primality testing. Default: 50\n");
                                	fprintf(stderr, "    -n <pbfile> : Public key file is <pbfile>. Default: rsa.pub\n");
                                	fprintf(stderr, "    -d <pvfile> : Private key file is <pvfile>. Default: rsa.priv\n");
                                	fprintf(stderr, "    -v          : Enable verbose output.\n");
                                	fprintf(stderr, "    -h          : Display program synopsis and usage.\n");
					return 1;
				}

			case 'n':
				pub_name = optarg;//change the public file name
				break;

			case 'd':
				priv_name = optarg;//change the private file name
				break;

			case 's':
                                seed = strtoul(optarg, NULL, 10);//set the seed to input
                                break;	

			case 'v':
				verbose = true;//set verbose output to true
				break;

			case 'h'://print help message
				fprintf(stderr, "Usage: ./keygen [options]\n");
                                fprintf(stderr, "  ./keygen generates a public / private key pair, placing the keys into the public and private\n");
                                fprintf(stderr, "  key files as specified below. The keys have a modulus (n) whose length is specified in\n");
                                fprintf(stderr, "  the program options.\n");
                                fprintf(stderr, "    -s <seed>   : Use <seed> as the random number seed. Default: time()\n");
                                fprintf(stderr, "    -b <bits>   : Public modulus n must have at least <bits> bits. Default: 1024\n");
                                fprintf(stderr, "    -i <iters>  : Run <iters> Miller-Rabin iterations for primality testing. Default: 50\n");
                                fprintf(stderr, "    -n <pbfile> : Public key file is <pbfile>. Default: rsa.pub\n");
                                fprintf(stderr, "    -d <pvfile> : Private key file is <pvfile>. Default: rsa.priv\n");
                                fprintf(stderr, "    -v          : Enable verbose output.\n");
                                fprintf(stderr, "    -h          : Display program synopsis and usage.\n");
				return 0;
			
			default://print help message and error
				fprintf(stderr, "Usage: ./keygen [options]\n");
                                fprintf(stderr, "  ./keygen generates a public / private key pair, placing the keys into the public and private\n");
                                fprintf(stderr, "  key files as specified below. The keys have a modulus (n) whose length is specified in\n");
                                fprintf(stderr, "  the program options.\n");
                                fprintf(stderr, "    -s <seed>   : Use <seed> as the random number seed. Default: time()\n");
                                fprintf(stderr, "    -b <bits>   : Public modulus n must have at least <bits> bits. Default: 1024\n");
                                fprintf(stderr, "    -i <iters>  : Run <iters> Miller-Rabin iterations for primality testing. Default: 50\n");
                                fprintf(stderr, "    -n <pbfile> : Public key file is <pbfile>. Default: rsa.pub\n");
                                fprintf(stderr, "    -d <pvfile> : Private key file is <pvfile>. Default: rsa.priv\n");
                                fprintf(stderr, "    -v          : Enable verbose output.\n");
                                fprintf(stderr, "    -h          : Display program synopsis and usage.\n");
				return 1;

		}
	}
	pbfile = fopen(pub_name, "w");//open the public file 
	if(pbfile == NULL){//if file doesnt exist return error and message
		fprintf(stderr, "pbfile could not open");
		return 1;
	}

	pvfile = fopen(priv_name, "w");//open the private file
	if(pvfile == NULL){//if file doesnt exist return error and message
                fprintf(stderr, "pvfile could not open");
                return 1;
        }

	int fchmod_var = fileno(pvfile);
	if(fchmod(fchmod_var, S_IRUSR | S_IWUSR)){//if file permissions are incorrect then return message and error
		fprintf(stderr, "pvfile permissions not correct");
		return 1;
	}

	randstate_init(seed);//initialize seed
	rsa_make_pub(p, q, n, e, nbits, iters);//make public key
	rsa_make_priv(d, e, p, q);//make private key

	username = getenv("USER");//get the username and create the signiture
	mpz_set_str(m, username, 62);
	rsa_sign(s, m, d, n);

	rsa_write_pub(n, e, s, username, pbfile);//write the information for each file 
	rsa_write_priv(n, d, pvfile);
	
	uint64_t s_bits = mpz_sizeinbase(s, 2);//for verbose output
	uint64_t p_bits = mpz_sizeinbase(p, 2);
	uint64_t q_bits = mpz_sizeinbase(q, 2);
        uint64_t n_bits = mpz_sizeinbase(n, 2);
	uint64_t e_bits = mpz_sizeinbase(e, 2);
        uint64_t d_bits = mpz_sizeinbase(d, 2);	

	if(verbose == true){//if verbose output was selected print below
		gmp_fprintf(stderr, "username: %s\n", username);
		gmp_fprintf(stderr, "user signature (%lu): %Zu\n", s_bits, s);
		gmp_fprintf(stderr, "p (%lu bits): %Zu\n", p_bits, p);
		gmp_fprintf(stderr, "q (%lu bits): %Zu\n", q_bits, q);
		gmp_fprintf(stderr, "n - modulus (%lu bits): %Zu\n", n_bits, n);
		gmp_fprintf(stderr, "e - public exponent (%lu bits): %Zu\n", e_bits, e);
		gmp_fprintf(stderr, "d - private exponent (%lu bits): %Zu\n", d_bits, d);
	}

	fclose(pbfile);//close the files
	fclose(pvfile);

	randstate_clear();//clear the randstate and temp variables
	mpz_clears(p, q, n, e, d, m, s, NULL);
}


