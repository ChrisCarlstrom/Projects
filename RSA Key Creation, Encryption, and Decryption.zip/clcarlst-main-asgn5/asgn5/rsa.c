#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>
#include "rsa.h"
#include "numtheory.h"
#include <gmp.h>
#include "randstate.h"





void rsa_make_pub(mpz_t p, mpz_t q, mpz_t n, mpz_t e, uint64_t nbits, uint64_t iters){

	mpz_t calc_n;//initialize temp variables
	mpz_init(calc_n);

	mpz_t temp1;
	mpz_init(temp1);

	mpz_t new_p;
	mpz_init(new_p);

	mpz_t new_q;
	mpz_init(new_q);

	mpz_t result;
	mpz_init(result);

	mpz_t num;
	mpz_init(num);

	mpz_t out;
	mpz_init(out);


	uint64_t least = (nbits / 4);//create bit ranges and get random bit amounts
	uint64_t greatest = ((nbits * 3) / 4);

	uint64_t pbits = (random() % (greatest + 1 - least)) + least; 
	uint64_t qbits = (nbits - pbits);

	make_prime(p, pbits, iters);//call make prime for p and q with bit amounts
	make_prime(q, qbits, iters);

	mpz_set(new_p, p);//set new_p and new_q to do calculations
	mpz_sub_ui(new_p, new_p, 1);

	mpz_set(new_q, q);
	mpz_sub_ui(new_q, new_q, 1);
	
	mpz_mul(n, p, q);//create calc_n to use for calculations
	mpz_set(calc_n, n);

	mpz_add(temp1, p, q);//compute Carmichaels function of n
	mpz_sub(calc_n, calc_n, temp1);
	mpz_add_ui(calc_n, calc_n, 1);
	mpz_abs(calc_n, calc_n);
		
	gcd(result, new_p, new_q);
	mpz_fdiv_q(calc_n, calc_n, result);

	while((mpz_cmp_ui(out, 1) != 0) || (mpz_sizeinbase(num, 2) < nbits)){//finds number that is coprime with Carmichaels function of n
		mpz_urandomb(num, state, nbits);
		gcd(out, calc_n, num);
	}
	mpz_set(e, num);
	mpz_clears(temp1, new_p, new_q, result, num, out, calc_n, NULL);//clear all temp variables
}





void rsa_write_pub(mpz_t n, mpz_t e, mpz_t s, char username[], FILE *pbfile){
	
	gmp_fprintf(pbfile, "%Zx\n\n%Zx\n\n%Zx\n\n%s\n\n", n, e, s, username);//prints public information
}



void rsa_read_pub(mpz_t n, mpz_t e, mpz_t s, char username[], FILE *pbfile){
	
	gmp_fscanf(pbfile, "%Zx\n\n%Zx\n\n%Zx\n\n%s\n\n", n, e, s, username);//reads public information
}



void rsa_make_priv(mpz_t d, mpz_t e, mpz_t p, mpz_t q){
	
	mpz_t new_p;//initialize temp variables 
	mpz_init(new_p);

	mpz_t new_q;
	mpz_init(new_q);

	mpz_t temp1;
	mpz_init(temp1);

	mpz_t n;
	mpz_init(n);

	mpz_t result;
	mpz_init(result);

	mpz_t temp2;
	mpz_init(temp2);


	mpz_set(new_p, p);//create new_p and new_q
        mpz_sub_ui(new_p, new_p, 1);

        mpz_set(new_q, q);
        mpz_sub_ui(new_q, new_q, 1);

        mpz_mul(n, p, q);//create n

        mpz_add(temp1, p, q);//Carmichaels function of n
        mpz_sub(n, n, temp1);
        mpz_add_ui(n, n, 1);
        mpz_abs(n, n);

        gcd(result, new_p, new_q);
        mpz_fdiv_q(n, n, result);	


	mod_inverse(d, e, n);//call mod inverse
	mpz_clears(new_p, new_q, temp1, n, result, temp2, NULL);//clear temp variables
}


void rsa_write_priv(mpz_t n, mpz_t d, FILE *pvfile){
	
	gmp_fprintf(pvfile, "%Zx\n\n%Zx\n\n", n, d);//print private key information
}




void rsa_read_priv(mpz_t n, mpz_t d, FILE *pvfile){
	
	gmp_fscanf(pvfile, "%Zx\n\n%Zx\n\n", n, d);//read private key information
}




void rsa_encrypt(mpz_t c, mpz_t m, mpz_t e, mpz_t n){
	
	pow_mod(c, m, e, n);//calls pow_mod for encryption
}



void rsa_encrypt_file(FILE *infile, FILE *outfile, mpz_t n, mpz_t e){

	mpz_t temp_n;
	mpz_init_set(temp_n, n);//create temp variables 

	mpz_t temp_e;
	mpz_init_set(temp_e, e);

	mpz_t m;
	mpz_init(m);

	mpz_t c;
	mpz_init(c);

	uint8_t k = ((mpz_sizeinbase(temp_n, 2) - 1) / 8);//create k value
	while(feof(infile) == 0){//while not at the end of the file
		uint8_t *array;
		array = (uint8_t*)calloc(k, sizeof(uint8_t));//create array for bits to go into
		array[0] = 0xFF;//set 0th element to workaround bit
		uint64_t j = fread(array+1, sizeof(uint8_t), k-1, infile);//read from infile 
		mpz_import(m, j+1, 1, sizeof(uint8_t), 1, 0, array);//put file elements into the array
		rsa_encrypt(c, m, e, n);//encrypt the array bits
		gmp_fprintf(outfile, "%Zx\n\n", c);//print the encrypted bits to outfile
		free(array);//clear the array for another iteration
	}
	mpz_clears(temp_n, temp_e, m, c, NULL);//clear temp variables
}



void rsa_decrypt(mpz_t m, mpz_t c, mpz_t d, mpz_t n){
	
	pow_mod(m, c, d, n);//call pow_mod to decryption
}



void rsa_decrypt_file(FILE *infile, FILE *outfile, mpz_t n, mpz_t d){

	mpz_t temp_n;//initialize temp variables
        mpz_init_set(temp_n, n);

        mpz_t temp_d;
        mpz_init_set(temp_d, d);

        mpz_t m;
        mpz_init(m);

        mpz_t c;
        mpz_init(c);

	uint64_t j;


        uint8_t k = ((mpz_sizeinbase(temp_n, 2) - 1) / 8);//create k variable
        while(feof(infile) == 0){ //while not at end of file
		uint8_t *array;
                array = (uint8_t*)calloc(k, sizeof(uint8_t));//create array for the bits to be stored in
                gmp_fscanf(infile, "%Zx\n\n", c);//reads infile elements
                rsa_decrypt(m, c, d, n);//decrypts the array bits
		mpz_export(array, &j, 1, sizeof(uint8_t), 1, 0, m);//exports the decrypted array bits
                fwrite(array+1, sizeof(uint8_t), j-1, outfile);//prints array bits to outfile
                free(array);//clears array for next iteration
        }
	mpz_clears(temp_n, temp_d, m, c, NULL);//clears temp variables
}




void rsa_sign(mpz_t s, mpz_t m, mpz_t d, mpz_t n){
	
	pow_mod(s, m, d, n);//creates signiture
}



bool rsa_verify(mpz_t m, mpz_t s, mpz_t e, mpz_t n){

	mpz_t temp;//verifies signiture by creating a temp and comparing the temp to the actual signiture
	mpz_init(temp);
	pow_mod(temp, s, e, n);
	if(mpz_cmp(temp, m) == 0){
		mpz_clear(temp);
		return true;//return true if the match and false if they dont
	}else{
	        mpz_clear(temp);	
		return false;
	}
}







