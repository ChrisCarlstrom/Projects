#include <stdio.h>
#include "rsa.h"
#include "numtheory.h"
#include "randstate.h"
#include <stdlib.h>
#include <inttypes.h>
#include <stdint.h>
#include <stdbool.h>
#include <unistd.h>
#include <string.h>
#define OPTIONS "i:o:n:vh"



int main(int argc, char **argv) {

	int opt = 0;//option counter

	mpz_t n, e, s, m;//initialize temp variables
	mpz_inits(n, e, s, m, NULL);

	char *username;//initialize other variables
	char *key_file_name = "rsa.pub";
	FILE *infile = stdin;
        FILE *outfile = stdout;
	FILE *key_file;
	bool verbose = false;



        while ((opt = getopt(argc, argv, OPTIONS)) != -1) {//while there are more options
                switch (opt) {
			case 'i':
                                infile = fopen(optarg, "r");//open infile if specified
				if(infile == NULL){//return error and message if doesnt exist
					fprintf(stderr, "infile could not open\n");
					return 1;
				}
                                break;

                        case 'o':
				outfile = fopen(optarg, "w");//open infile if specified
                                if(outfile == NULL){//return error and message
                                        fprintf(stderr, "outfile could not open\n");
                                        return 1;
                                }
                                break;
	
                        case 'n':
                                key_file_name = optarg;//set key_file to input
                                break;

                        case 'v':
                                verbose = true;//set verbose output to true
                                break;

                        case 'h'://print help message
				fprintf(stderr, "Usage: ./encrypt [options]\n");
                                fprintf(stderr, "  ./encrypt encrypts an input file using the specified public key file,\n");
                                fprintf(stderr, "  writing the result to the specified output file.\n");
                                fprintf(stderr, "    -i <infile> : Read input from <infile>. Default: standard input.\n");
                                fprintf(stderr, "    -o <outfile>: Write output to <outfile>. Default: standard output.\n");
                                fprintf(stderr, "    -n <keyfile>: Public key is in <keyfile>. Default: rsa.pub.\n");
                                fprintf(stderr, "    -v          : Enable verbose output.\n");
                                fprintf(stderr, "    -h          : Display program synopsis and usage.\n");
                                return 0;
			default://print help message and error
				fprintf(stderr, "Usage: ./encrypt [options]\n");
                                fprintf(stderr, "  ./encrypt encrypts an input file using the specified public key file,\n");
                                fprintf(stderr, "  writing the result to the specified output file.\n");
                                fprintf(stderr, "    -i <infile> : Read input from <infile>. Default: standard input.\n");
                                fprintf(stderr, "    -o <outfile>: Write output to <outfile>. Default: standard output.\n");
                                fprintf(stderr, "    -n <keyfile>: Public key is in <keyfile>. Default: rsa.pub.\n");
                                fprintf(stderr, "    -v          : Enable verbose output.\n");
                                fprintf(stderr, "    -h          : Display program synopsis and usage.\n");
                                return 1;
		}
	}
	key_file = fopen(key_file_name, "r");//open file to read
        if(key_file == NULL){//if doesnt exist return error and message
                fprintf(stderr, "keyfile could not open\n");
                return 1;
        }	
	

	username = getenv("USER");//get user name and verify signature
        mpz_set_str(m, username, 62);	
	rsa_read_pub(n, e, s, username, key_file);
	if(rsa_verify(m, s, e, n) == false){//return error if cannot verify signature
		fprintf(stderr, "signature could not be verified\n");
		return 1;
	}

	uint64_t s_bits = mpz_sizeinbase(s, 2);//for verbose output
        uint64_t n_bits = mpz_sizeinbase(n, 2);
        uint64_t e_bits = mpz_sizeinbase(e, 2);

        if(verbose == true){//print if verbose is selected
                gmp_fprintf(stderr, "username: %s\n", username);
                gmp_fprintf(stderr, "user signature (%lu): %Zu\n", s_bits, s);
                gmp_fprintf(stderr, "n - modulus (%lu bits): %Zu\n", n_bits, n);
                gmp_fprintf(stderr, "e - public exponent (%lu bits): %Zu\n", e_bits, e);
        }
	rsa_encrypt_file(infile, outfile, n, e);//encrypt the infile and print result to outfile
	fclose(infile);//close files and clar variables
	fclose(outfile);
	fclose(key_file);
	mpz_clears(m, s, e, n, NULL);

	return 0;
}

