#include <stdio.h>
#include "rsa.h"
#include "numtheory.h"
#include "randstate.h"
#include <stdlib.h>
#include <inttypes.h>
#include <stdint.h>
#include <stdbool.h>
#include <unistd.h>
#include <string.h>
#define OPTIONS "i:o:n:vh"


int main(int argc, char **argv) {

        int opt = 0;//option counter

        mpz_t n, d;//initialize variables
        mpz_inits(n, d, NULL);

        FILE *infile = stdin;//initialize more variables
        FILE *outfile = stdout;
        FILE *key_file;
        char *key_file_name = "rsa.priv";
        bool verbose = false;



        while ((opt = getopt(argc, argv, OPTIONS)) != -1) {//while there are more options
                switch (opt) {
                        case 'i':
				infile = fopen(optarg, "r");//opee file to read 
			        if(infile == NULL){//if file doesnt exist then return error and message
                			fprintf(stderr, "infile could not open\n");
                			return 1;
        			}
				break;

                        case 'o':
                                outfile = fopen(optarg, "w");//open outfile to write
        			if(outfile == NULL){//if file doesnt exist then return error and message
                			fprintf(stderr, "outfile could not open\n");
                			return 1;
        			}
                                break;

                        case 'n':
                                key_file_name = optarg;//set key_file_name to input
                                break;

                        case 'v':
                                verbose = true;//set verbose output to true
                                break;

			case 'h'://print help message
				fprintf(stderr, "Usage: ./decrypt [options]\n");
                                fprintf(stderr, "  ./decrypt decrypts an input file using the specified private key file,\n");
                                fprintf(stderr, "  writing the result to the specified output file.\n");
                                fprintf(stderr, "    -i <infile> : Read input from <infile>. Default: standard input.\n");
                                fprintf(stderr, "    -o <outfile>: Write output to <outfile>. Default: standard output.\n");
                                fprintf(stderr, "    -n <keyfile>: Private key is in <keyfile>. Default: rsa.priv.\n");
                                fprintf(stderr, "    -v          : Enable verbose output.\n");
                                fprintf(stderr, "    -h          : Display program synopsis and usage.\n");
                                return 0;
                        default://print help message and return error
				fprintf(stderr, "Usage: ./decrypt [options]\n");
                                fprintf(stderr, "  ./decrypt decrypts an input file using the specified private key file,\n");
                                fprintf(stderr, "  writing the result to the specified output file.\n");
                                fprintf(stderr, "    -i <infile> : Read input from <infile>. Default: standard input.\n");
                                fprintf(stderr, "    -o <outfile>: Write output to <outfile>. Default: standard output.\n");
                                fprintf(stderr, "    -n <keyfile>: Private key is in <keyfile>. Default: rsa.priv.\n");
                                fprintf(stderr, "    -v          : Enable verbose output.\n");
                                fprintf(stderr, "    -h          : Display program synopsis and usage.\n");
                                return 1;
                }
        }

        key_file = fopen(key_file_name, "r");//open key file to write
        if(key_file == NULL){//if file doesnt exist then return error and message
                fprintf(stderr, "keyfile could not open\n");
                return 1;
        }


        rsa_read_priv(n, d, key_file);//read priv file

        uint64_t n_bits = mpz_sizeinbase(n, 2);//for verbose output
	uint64_t d_bits = mpz_sizeinbase(d, 2);

        if(verbose == true){//print below if verbose output is true
                gmp_fprintf(stderr, "n - modulus (%lu bits): %Zu\n", n_bits, n);
		gmp_fprintf(stderr, "d - private exponent (%lu bits): %Zu\n", d_bits, d);
        }

        rsa_decrypt_file(infile, outfile, n, d);//decrypt the infile and print to outfile
        fclose(infile);//close files and clear temp variables
	fclose(outfile);
	fclose(key_file);
        mpz_clears(n, d, NULL);

        return 0;
}




