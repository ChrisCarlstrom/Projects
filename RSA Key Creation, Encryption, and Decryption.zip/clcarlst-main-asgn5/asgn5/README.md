In order to run the program you will need the following files: decrypt.c, encrypt.c, keygen.c, numtheory.c, numtheory.h, randstate.c, randstate.h, rsa.c, rsa.h, and Makefile. To build the program type "make" in the terminal. To run keygen type ./keygen with any of its command line options listed below. To run encrypt type ./encrypt with any of its command line options listed below. To run decrypt type ./decrypt with any of ots command line options listed below.


FOR BEST PERFORMANCE BE SURE TO RUN WITH YOUR LAPTOP IN BEST PERFORMANCE MODE, IT WILL REDUCE THE TIME IT TAKES TO RUN KEYGEN


Command line options for keygen:
-b: specifies the minimum bits needed for the public modulus n(default: 1024).
-i: specifies the number of Miller-Rabin iterations for testing primes (default: 50).
-n pbfile: specifies the public key file (default: rsa.pub).
-d pvfile: specifies the private key file (default: rsa.priv).
-s: specifies the random seed for the random state initialization (default: the seconds since the UNIX epoch, given by time(NULL)).
-v: enables verbose output.
-h: displays program synopsis and usage.



Command line options for encrypt:
-i: specifies the input file to encrypt (default: stdin).
-o: specifies the output file to encrypt (default: stdout).
-n: specifies the file containing the public key (default: rsa.pub).
-v: enables verbose output.
-h: displays program synopsis and usage.



Command line options for decrypt:
-i: specifies the input file to decrypt (default: stdin).
-o: specifies the output file to decrypt (default: stdout).
-n: specifies the file containing the private key (default: rsa.priv).
-v: enables verbose output.
-h: displays program synopsis and usage.

